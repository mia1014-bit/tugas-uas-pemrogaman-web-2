<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    // Menampilkan dashboard admin
    public function index()
    {
        return view('admin/dashboard');
    }

    // Daftar Makeup
    public function daftarMakeup()
    {
        $makeupModel = model('MakeupModel'); // Menggunakan MakeupModel

        // Mengambil semua data makeup
        $data['makeups'] = $makeupModel->findAll();
        return view('admin/daftar-makeup', $data); // Mengarahkan ke tampilan daftar makeup
    }

    // Menambahkan Makeup Baru
    public function daftarMakeupTambah()
    {
        return view('admin/daftar-makeup-tambah'); // Menampilkan form tambah makeup
    }

    public function createMakeup()
    {
        $data = $this->request->getPost(); // Mengambil data dari form
        $file = $this->request->getFile('cover'); // Mengambil file gambar

        if (!$file->hasMoved()) {
            $path = $file->store('images'); // Menyimpan gambar di folder images
            $data['cover'] = $path; // Menyimpan path gambar
        }

        $makeupModel = model('MakeupModel'); // Menggunakan MakeupModel

        // Menyimpan data makeup
        if ($makeupModel->insert($data, false)) {
            return redirect()->to('admin/daftar-makeup')->with('berhasil', 'Data makeup berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-makeup')->with('gagal', 'Data makeup gagal disimpan!');
        }
    }

    // Edit Makeup
    public function daftarMakeupEdit($id)
    {
        $makeupModel = model('MakeupModel');
        $data['makeup'] = $makeupModel->find($id); // Mengambil data makeup berdasarkan ID
        return view('admin/daftar-makeup-edit', $data); // Mengarahkan ke tampilan edit makeup
    }

    // Update Makeup
    public function daftarMakeupUpdate($id)
    {
        $data = $this->request->getPost(); // Mengambil data yang telah diedit
        $makeupModel = model('MakeupModel');

        // Mengupdate data makeup
        if ($makeupModel->update($id, $data)) {
            return redirect()->to('admin/daftar-makeup')->with('berhasil', 'Data makeup berhasil diperbarui!');
        } else {
            return redirect()->to('admin/daftar-makeup')->with('gagal', 'Data makeup gagal diperbarui!');
        }
    }

    // Hapus Makeup
    public function daftarMakeupHapus($id)
    {
        $makeupModel = model('MakeupModel');
        
        // Menghapus data makeup
        $makeupModel->delete($id);
        return redirect()->to('admin/daftar-makeup')->with('berhasil', 'Data makeup berhasil dihapus!');
    }

    // Transaksi
    public function transaksi()
    {
        return view('admin/transaksi');
    }

    // Ubah Status Transaksi
    public function transaksiUbahStatus()
    {
        return view('admin/transaksi-ubah-status');
    }

    // Hapus Transaksi
    public function transaksiHapus()
    {
        return view('admin/transaksi-hapus');
    }

    // Daftar Pelanggan
    public function pelanggan()
    {
        return view('admin/pelanggan');
    }

    // Hapus Pelanggan
    public function pelangganHapus()
    {
        return view('admin/pelanggan-hapus');
    }
}
