<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko Makeup Online</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=Dancing+Script:wght@400&display=swap"
      rel="stylesheet"
    />
    <style>
      body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #f8d7e5, #f1a7d1); /* Gradasi pink pastel ke pink gelap */
        color: #9b3d55; /* Pink gelap untuk teks */
        min-height: 100vh;
      }

      header {
        background: linear-gradient(135deg, #f8d7e5, #f1a7d1); /* Gradasi pink pastel ke pink gelap */
        color: #9b3d55; /* Pink gelap */
        text-align: center;
        position: relative;
        padding: 40px 0;
        border-bottom: 5px solid #9b3d55; /* Garis border pink gelap */
      }

      h1 {
        font-size: 3.5rem;
        font-weight: 700;
        font-family: 'Poppins', sans-serif;
        color: #9b3d55; /* Pink gelap */
      }

      h1 span {
        font-size: 1.7rem;
        display: block;
        color: #9b3d55; /* Pink gelap yang lebih lembut untuk sub teks */
      }

      .btn-primary {
        background-color: #9b3d55; /* Pink gelap */
        border-color: #9b3d55;
        font-weight: 600;
        transition: transform 0.2s, box-shadow 0.2s;
      }

      .btn-primary:hover {
        background-color: #762a3f; /* Pink gelap lebih tua untuk hover */
        transform: scale(1.1);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      }

      .card {
        border: none;
        border-radius: 10px;
        background: linear-gradient(135deg, #f8d7e5, #f1a7d1); /* Gradasi pink pastel */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s;
      }

      .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      }

      footer {
        background: linear-gradient(135deg, #f8d7e5, #f1a7d1); /* Gradasi pink pastel ke pink gelap */
        color: #9b3d55; /* Pink gelap */
        text-align: center;
        padding: 20px 0;
        border-top: 5px solid #9b3d55; /* Garis border pink gelap */
        font-size: 1rem;
      }

      .form-control {
        border: 1px solid #9b3d55;
        border-radius: 5px;
      }

      .form-control:focus {
        box-shadow: 0 0 5px rgba(255, 130, 166, 0.5);
        border-color: #762a3f; /* Fokus pada border pink gelap */
      }

      .cart-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        background-color: #9b3d55;
        color: white;
        padding: 12px 20px;
        border-radius: 5px;
        font-weight: 600;
        transition: transform 0.2s, box-shadow 0.2s;
        display: inline-block;
      }

      .cart-btn:hover {
        background-color: #762a3f; /* Hover pada tombol cart dengan pink lebih gelap */
        transform: scale(1.1);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      }

      .login-logout {
        display: none; /* Menghilangkan menu login/logout */
      }

      .card-img-top {
        object-fit: cover;
        height: 200px;
        border-radius: 10px;
      }
    </style>
  </head>
  <body>
    <header>
      <div class="container">
        <h1>
          Toko Makeup Online
          <span style="color: #9b3d55;">✨ Temukan produk favoritmu! ✨</span>
        </h1>
        <a href="<?= base_url() ?>chart" class="cart-btn">
          Keranjang Belanja <span class="badge text-bg-warning">4</span>
        </a>
      </div>
    </header>

    <div class="container mt-5">
      <!-- Welcome Section -->
      <div class="row bg-light p-5 rounded shadow-sm">
        <div class="col-md-6">
          <h2 class="mb-4" style="color: #9b3d55;">Selamat Datang!</h2>
          <p>
            Kami menyediakan produk makeup dari berbagai merek ternama dengan
            harga terjangkau. Yuk, cek koleksi kami!
          </p>
          <a href="#" class="btn btn-primary btn-lg mt-3">Lihat Produk</a>
        </div>
        <div class="col-md-6">
          <form action="">
            <h3 class="mb-4" style="color: #9b3d55;">Cari Produk</h3>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="Nama Produk" />
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="Merek" />
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="Kategori" />
            </div>
            <button class="btn btn-primary w-100">Cari</button>
          </form>
        </div>
      </div>

      <!-- Best Seller Section -->
      <h2 class="my-5 text-center" style="color: #9b3d55;">✨ Produk Best Seller ✨</h2>
      <div class="row g-4">
        <div class="col-md-3">
          <div class="card">
            <img src="images/BLUSHON.webp" class="card-img-top" alt="Blush On" />
            <div class="card-body text-center">
              <h5 class="card-title">Blush On</h5>
              <p class="card-text">Rp 120,000,-</p>
              <a href="#" class="btn btn-primary w-100">Add to Cart</a>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card">
            <img src="images/LIPSTICK.webp" class="card-img-top" alt="Lipstick" />
            <div class="card-body text-center">
              <h5 class="card-title">Lipstick</h5>
              <p class="card-text">Rp 180,000,-</p>
              <a href="#" class="btn btn-primary w-100">Add to Cart</a>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card">
            <img src="images/MASCARA.webp" class="card-img-top" alt="Mascara" />
            <div class="card-body text-center">
              <h5 class="card-title">Mascara</h5>
              <p class="card-text">Rp 99,000,-</p>
              <a href="#" class="btn btn-primary w-100">Add to Cart</a>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card">
            <img src="images/SKINTIFIC.png" class="card-img-top" alt="Cushion" />
            <div class="card-body text-center">
              <h5 class="card-title">Cushion</h5>
              <p class="card-text">Rp 180,000,-</p>
              <a href="#" class="btn btn-primary w-100">Add to Cart</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <footer>
      <p class="mb-0">Copyright 2024. Toko Makeup Online. All Rights Reserved.</p>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
