<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Make-Up</title>
    <link rel="stylesheet" href="/path/to/your/css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Konfirmasi Hapus Make-Up</h1>
        
        <?php if (isset($makeup)): ?>
            <p>Apakah Anda yakin ingin menghapus produk make-up dengan data berikut?</p>
            <ul>
                <li><strong>Nama:</strong> <?= htmlspecialchars($makeup['nama']); ?></li>
                <li><strong>Merek:</strong> <?= htmlspecialchars($makeup['merek']); ?></li>
                <li><strong>Kategori:</strong> <?= htmlspecialchars($makeup['kategori']); ?></li>
                <li><strong>Tanggal Rilis:</strong> <?= htmlspecialchars($makeup['tanggal_rilis']); ?></li>
                <li><strong>Gambar:</strong> <?= htmlspecialchars($makeup['gambar']); ?></li>
                <li><strong>Harga:</strong> Rp <?= number_format($makeup['harga'], 2, ',', '.'); ?></li>
            </ul>
            
            <form action="/admin/daftar-makeup/hapus/<?= $makeup['id']; ?>" method="post">
                <?= csrf_field(); ?>
                
                <button type="submit" class="btn btn-danger">Hapus</button>
                <a href="/admin/daftar-makeup" class="btn btn-secondary">Batal</a>
            </form>
        <?php else: ?>
            <p>Data make-up tidak ditemukan.</p>
            <a href="/admin/daftar-makeup" class="btn btn-secondary">Kembali ke Daftar Make-Up</a>
        <?php endif; ?>
    </div>
</body>
</html>
