<?= $this->extend('admin/template'); ?>

<?= $this->section('main'); ?>

<h2 class="mb-5">Daftar Make Up</h2>

<div class="mb-3">
    <a href="<?= base_url('admin/daftar-Makeup/tambah')?>" class="btn btn-primary">Tambah Make Up</a>
</div>

<div class="mb-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Produk</th>
                <th scope="col">Merek</th>
                <th scope="col">Kategori</th>
                <th scope="col">Deskripsi</th>
                <th scope="col">Harga</th>
                <th scope="col">Gambar</th>
                <th scope="col">Stok</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($makeups as $makeup): ?>
            <tr>
                <th scope="row"><?= $makeup['id'] ?></th>
                <td><?= $makeup['nama_produk'] ?></td>
                <td><?= $makeup['merek'] ?></td>
                <td><?= $makeup['kategori'] ?></td>
                <td><?= $makeup['deskripsi'] ?></td>
                <td>Rp <?= number_format($makeup['harga'], 0, ',', '.') ?></td>
                <td>
                    <img src="<?= base_url($makeup['gambar']) ?>" alt="Gambar Produk" style="width: 150px; height: auto;">
                </td>
                <td><?= $makeup['stok'] ?></td>
                <td>
                    <a href="<?= base_url('admin/daftar-make-up/edit') ?>/<?= $makeup['id'] ?>" class="btn btn-success">Edit</a>
                    <a href="<?= base_url('admin/daftar-make-up/hapus') ?>/<?= $makeup['id'] ?>" class="btn btn-danger">Hapus</a>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?= $this->endSection(); ?>
