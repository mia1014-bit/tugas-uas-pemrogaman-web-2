<?= $this->extend('admin/template')?>

<?= $this->section('main')?>
<h2 class="mb-5">Tambah Make Up</h2>

<div class="w-50">
    <form action="<?= base_url('admin/daftar-make-up/tambah')?>" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nama_produk">Nama Produk</label>
            <input type="text" class="form-control" name="nama_produk" id="nama_produk" required>
        </div>
        <div class="mb-3">
            <label for="merek">Merek</label>
            <input type="text" class="form-control" name="merek" id="merek" required>
        </div>
        <div class="mb-3">
            <label for="kategori">Kategori</label>
            <input type="text" class="form-control" name="kategori" id="kategori" required>
        </div>
        <div class="mb-3">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="harga">Harga</label>
            <input type="number" class="form-control" name="harga" id="harga" required>
        </div>
        <div class="mb-3">
            <label for="gambar">Gambar</label>
            <input type="file" class="form-control" name="gambar" id="gambar" accept="image/*" required>
        </div>
        <div class="mb-3">
            <label for="stok">Stok</label>
            <input type="number" class="form-control" name="stok" id="stok" required>
        </div>
        <div class="mb-3">
            <a href="<?= base_url('admin/daftar-make-up')?>" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>

<?= $this->endSection()?>
