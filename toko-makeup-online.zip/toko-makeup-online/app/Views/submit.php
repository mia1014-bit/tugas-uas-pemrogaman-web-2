<?= $this->extend('template') ?>

<?= $this->section('main') ?>
<div class="container">
    <div class="py-5">
        <!-- Success Alert -->
        <div class="alert alert-success bg-gradient-pink-light text-pink-dark border-0 rounded-3 shadow-sm">
            <strong>Berhasil!</strong> order anda akan segera diproses!
        </div>
        
        <!-- Back to Shopping Button -->
        <div class="mt-5">
            <a href="<?= base_url() ?>" class="btn btn-gradient-pink-dark w-100 py-3 rounded-pill">
                Kembali berbelanja
            </a>
        </div>
    </div>
</div>

<style>
    :root {
        --pink-light: #ffd6e4;
        --pink-dark: #ff007f;
    }

    body {
        background-color: #f8faff;
    }

    .alert {
        background: linear-gradient(135deg, var(--pink-light), #ffe4f7);
        color: var(--pink-dark);
        border: none;
        border-radius: 1rem;
        box-shadow: 0 4px 10px rgba(255, 0, 127, 0.2);
    }

    .btn-gradient-pink-dark {
        background: linear-gradient(135deg, var(--pink-dark), #ff66a3);
        color: white;
        font-weight: bold;
        border-radius: 1rem;
        transition: background 0.3s ease;
    }

    .btn-gradient-pink-dark:hover {
        background: linear-gradient(135deg, #ff66a3, var(--pink-dark));
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(255, 0, 127, 0.3);
    }

    .container {
        max-width: 600px;
        margin-top: 50px;
    }
</style>
<?= $this->endSection() ?>
